#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QStandardItemModel>   // for object models
#include <QDate>                // for date and time
#include "xlsxdocument.h"
#include <QMainWindow>
#include "window.h"
namespace Ui {
class frmAddDelivery;
}

class frmAddDelivery : public QMainWindow
{
    Q_OBJECT

public:

    explicit frmAddDelivery(QWidget *parent = nullptr);

    ~frmAddDelivery();



private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::frmAddDelivery *ui;
    int counter=0;
    Window *window;
    void addDelivery(QAbstractItemModel *model, const QString requiredDeliveryDate, const QString destination,
                      const QString transitMethod,  const QString classificationLevel,  const QString numberOfItems,
                     const QString mediaType,     const QString requiredStartDate);
    QAbstractItemModel *createDeliveryModel(QObject *parent);

};

#endif // MAINWINDOW_H
