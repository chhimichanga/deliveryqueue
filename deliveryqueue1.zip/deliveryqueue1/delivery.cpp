#include "delivery.h"

Delivery::Delivery()
{
    id = '\0';
    rdd = '\0';
    location = '\0';
    classification = '\0';
    mediaType = '\0';
    shippingMethod= '\0';
    rsd = '\0';
    nums = 0;
}
void Delivery::set_ID(string ID)
{
    id = ID;
}
void Delivery::set_RDD(string RDD)
{
    rdd = RDD;
}
void Delivery::set_Location (string Location)
{
    location = Location;
}
void  Delivery::set_Classification   (string Classification){
    classification = Classification;
}
void Delivery::set_MediaType (string MediaType)
{
    mediaType = MediaType;
}
void Delivery::set_ShippingMethod (string ShippingMethod )
{
    shippingMethod = ShippingMethod;
}
void Delivery::set_RSD (string RSD)
{
    rsd = RSD;
}
void Delivery::set_NUMS (int NUMS)
{
    nums = NUMS;
}
