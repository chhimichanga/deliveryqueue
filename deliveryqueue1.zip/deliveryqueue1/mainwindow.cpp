/*Michael Chhim
 * Bruce Roderiques
 * Michael Smith
 * Tuan_Son Le
 * Yun Yang
 */
//Delivery Queue Senior Project
#include <QStandardItemModel>   // for object models
#include <QDate>                // for date and time
#include "xlsxdocument.h"
#include "algorithm.h"
#include "delivery.h"
#include "mainwindow.h"
#include "ui_frmAddDelivery.h"
#include "window.h"
#include <Qfile>
#include <QDir>
#include <QMessageBox>
#include <QTextStream>
#include <sstream>
#include <fstream>
#include <iostream>
#define MAX_Deliveries_SIZE 100
frmAddDelivery::frmAddDelivery(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::frmAddDelivery)

{

    counter = 0;
    ui->setupUi(this);


//Classification ComboBox
    ui->cboClassification->addItem("Secret");
    ui->cboClassification->addItem("Confidential");
    ui->cboClassification->addItem("Unclassified");

//Location ComboBox
    ui->cboLocation ->addItem("Area 51 Nevada");
    ui->cboLocation ->addItem("King's Bay Georgia");
    ui->cboLocation ->addItem("Pensacola Florida");
    ui->cboLocation ->addItem("Great Lakes Illinois");
    ui->cboLocation ->addItem("Bremerton Washington");
    ui->cboLocation ->addItem("New London Connecticut");
    ui->cboLocation ->addItem("Rota Spain");
//mediaType Combobox

    ui->cboMediaType->addItem("Software");
    ui->cboMediaType->addItem("Hardware");
    ui->cboMediaType->addItem("Documentation");

//staffingLevel Combobox

    ui->cboStaffing->addItem("1");
    ui->cboStaffing->addItem("2");
    ui->cboStaffing->addItem("3");

//deliveryMethod Combobox
    ui->cboShipping->addItem("Hand Carried");
    ui->cboShipping->addItem("Shipping");
}

frmAddDelivery::~frmAddDelivery()
{
    delete ui;
}




void frmAddDelivery::on_pushButton_clicked()
{

    counter++;
    QFile file1("F:/save.csv");
    QTextStream out(&file1);
    if(!file1.open(QIODevice::WriteOnly |  QIODevice::Append | QIODevice::Text)){
           QMessageBox::information(this, "Title", "cannot open the file");
    }
    else{
        if(file1.pos() == 0){
            QString header;
            header = "ID,RDD,Location,Shipping Method,Classification,Items,Media Type,RSD";

            out << header << endl;
        }
        QString delivery;
        delivery = QString::number(counter);
        delivery += ',';
        delivery += ui->dteDeliveryDate->date().toString("dd/MM/yyyy");
        delivery += ',';
        delivery += ui->cboLocation->currentText();
        delivery += ',';
        delivery += ui->cboShipping->currentText();
        delivery += ',';
        delivery += ui->cboClassification->currentText();
        delivery += ',';
        delivery += QString::number(ui->spnNumberObjects->value());
        delivery += ',';
        delivery += ui->cboMediaType->currentText();
        delivery += ",";
        out << delivery << endl;
       QMessageBox::information(this, "Title", "Sucessfully submitted a delivery");
    }
//    Algorithm algorithm(data);
//    for(int w = 0; w < algorithm.getCount(); w++){
//         cout << data[w].get_ID() << "\t";
//         cout << data[w].get_RDD() << "\t";
//         cout << data[w].get_Location() << "\t";
//         cout << data[w].get_ShippingMethod() << "\t";
//         cout << data[w].get_Classification() << "\t";
//         cout << data[w].get_NUMS() << "\t" ;
//         cout << data[w].get_MediaType() << "\t" ;
//         cout << data[w].get_RSD() << "\t" ;
//         cout << endl;
//    }
}

void frmAddDelivery::on_pushButton_2_clicked()

{
    window = new Window();
    window->setSourceModel(createDeliveryModel(window));
    window->show();
//    Algorithm algorithm(data);
//    for(int w = 0; w < algorithm.getCount(); w++){
//         cout << data[w].get_ID() << "\t";
//         cout << data[w].get_RDD() << "\t";
//         cout << data[w].get_Location() << "\t";
//         cout << data[w].get_ShippingMethod() << "\t";
//         cout << data[w].get_Classification() << "\t";
//         cout << data[w].get_NUMS() << "\t" ;
//         cout << data[w].get_MediaType() << "\t" ;
//         cout << data[w].get_RSD() << "\t" ;
//         cout << endl;
//    }



}
void frmAddDelivery::addDelivery(QAbstractItemModel *model, const QString requiredDeliveryDate, const QString destination,
                  const QString transitMethod,  const QString classificationLevel,  const QString numberOfItems,
                 const QString mediaType,     const QString requiredStartDate)
{
    // insert a row below the last current row in the list
    model->insertRow(0);
    // set each field's value for the new row
    model->setData(model->index(0, 0), requiredDeliveryDate);
    model->setData(model->index(0, 1), destination);
    model->setData(model->index(0, 2), transitMethod);
    model->setData(model->index(0, 3), classificationLevel);
    model->setData(model->index(0, 4), numberOfItems);
    model->setData(model->index(0, 5), mediaType);
    model->setData(model->index(0, 6), requiredStartDate);
}

// abstract model
QAbstractItemModel* frmAddDelivery::createDeliveryModel(QObject *parent)
{
    Delivery data[MAX_Deliveries_SIZE];
    Algorithm algorithm(data);
    QXlsx::Document xlsx;
    QXlsx::Format format;
    format.setFontBold(true);
    format.setHorizontalAlignment(QXlsx::Format::AlignHCenter);
    xlsx.write("A1", "Required Delivery Date", format);
    xlsx.write("B1", "Destination", format);
    xlsx.write("C1", "Transit Method", format);
    xlsx.write("D1", "Classification Level", format);
    xlsx.write("E1", "Number of Items", format);
    xlsx.write("F1", "Media Type", format);
    xlsx.write("G1", "Required Start Date", format);
    xlsx.saveAs("Test.xlsx");

    // create an empty delivery table with 0 rows and 6 columns
    QStandardItemModel *deliveryTable = new QStandardItemModel(0, 10, parent);

    // set name of each table field (column)
    //
    deliveryTable->setHeaderData(0, Qt::Horizontal, xlsx.read("A1"));
    deliveryTable->setHeaderData(1, Qt::Horizontal, xlsx.read("B1"));
    deliveryTable->setHeaderData(2, Qt::Horizontal, xlsx.read("C1"));
    deliveryTable->setHeaderData(3, Qt::Horizontal, xlsx.read("D1"));
    deliveryTable->setHeaderData(4, Qt::Horizontal, xlsx.read("E1"));
    deliveryTable->setHeaderData(5, Qt::Horizontal, xlsx.read("F1"));
    deliveryTable->setHeaderData(6, Qt::Horizontal, xlsx.read("G1"));
    for(int w = 0; w < algorithm.getCount(); w++){
             cout << data[w].get_ID() << "\t";
             cout << data[w].get_RDD() << "\t";
             cout << data[w].get_Location() << "\t";
             cout << data[w].get_ShippingMethod() << "\t";
             cout << data[w].get_Classification() << "\t";
            cout << data[w].get_NUMS() << "\t" ;
             cout << data[w].get_MediaType() << "\t" ;
             cout << data[w].get_RSD() << "\t" ;
             cout << endl;
        }


    for(int w = 0; w < algorithm.getCount(); w++){
         QString requiredDeliveryDate = QString::fromStdString(data[w].get_RDD());
         QString destination = QString::fromStdString(data[w].get_Location());
         QString transitMethod = QString::fromStdString(data[w].get_ShippingMethod());
         QString classificationL = QString::fromStdString(data[w].get_Classification());
         string numberofItems1 = to_string(data[w].get_NUMS());
         QString numberOfItems = QString::fromStdString(numberofItems1);
         QString mediaType = QString::fromStdString(data[w].get_MediaType());
         QString requiredStartDate = QString::fromStdString(data[w].get_RSD());
         addDelivery(deliveryTable, requiredDeliveryDate, destination , transitMethod, classificationL, numberOfItems, mediaType, requiredStartDate);

    }
    //initialize loop increments and get today's date
    int colCount = 0;
    int rowCount = 0;
    QDate currentDate = QDate::currentDate();

//    //process for coloring an entire row based on the days to the included date based on the input date
//    //qDebug() << currentDate;
//    for(rowCount = 0; rowCount <9; rowCount++) {
//        //acquires date of the nth delivery based on rowCount and converts it to a comparable QDate
//        QString gettingColored = deliveryTable->data(deliveryTable->index(rowCount, 0)).toString();
//        QDate deliveryDate = QDate::fromString(gettingColored,"yyyy-MM-dd");

//        //qDebug() << deliveryDate;

//        if(currentDate.daysTo(deliveryDate) < 7){
//            //qDebug() << currentDate.daysTo(Date);
//            for(colCount = 0; colCount <6; colCount++) {
//                deliveryTable->setData(deliveryTable->index(rowCount, colCount),  QColor (255,0,0), Qt::BackgroundRole);
//            }
//        }
//        else
//        if(currentDate.daysTo(deliveryDate) < 14 && currentDate.daysTo(deliveryDate) > 7){
//            //qDebug() << currentDate.daysTo(Date);
//            for(colCount = 0; colCount <6; colCount++) {
//                deliveryTable->setData(deliveryTable->index(rowCount, colCount),  QColor (255,255,0), Qt::BackgroundRole);
//            }
//        }
//        else
//        if(currentDate.daysTo(deliveryDate) > 14){
//            for(colCount = 0; colCount <6; colCount++) {
//                deliveryTable->setData(deliveryTable->index(rowCount, colCount),  QColor (0,255,0), Qt::BackgroundRole);
//            }
//        }
//    }

    return deliveryTable;
}
