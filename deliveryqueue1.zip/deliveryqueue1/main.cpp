#include "window.h"
#include <QApplication>
#include <QStandardItemModel>   // for object models
#include <QDate>                // for date and time
#include "xlsxdocument.h"
#include "mainwindow.h"

#include "algorithm.h"
#include <delivery.h>
#include <iostream>
#define MAX_Deliveries_SIZE 100
 using namespace std;

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);


     frmAddDelivery w;
     w.show();


    return app.exec();
}
