#ifndef DELIVERY_H
#define DELIVERY_H
#include <string>
using namespace std;
class Delivery
{
   string id,
          rdd,
          location,
          classification,
          mediaType,
          shippingMethod,
          rsd;
   int  nums;
public:
   //  constructors
          Delivery();
   // Set variables
   void   set_ID(string ID);
   void   set_RDD (string RDD);
   void   set_Location   (string Location);
   void   set_Classification   (string Classification);
   void   set_MediaType   (string MediaType);
   void   set_ShippingMethod  (string ShippingMethod);
   void   set_RSD   (string RSD);
   void   set_NUMS   (int NUMS);
   // Get member variables
   string get_ID() {return id;}
   string get_RDD() {return rdd;}
   string  get_Location    () {return location;}
   string get_Classification() {return classification;}
   string   get_MediaType()   {return mediaType;}
   string   get_ShippingMethod()  {return shippingMethod;}
   string   get_RSD()   {return rsd;}
   int   get_NUMS()   {return nums;}
   void print_delivery_info();
};
#endif // DELIVERY_H
