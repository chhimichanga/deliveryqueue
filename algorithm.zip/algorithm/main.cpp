#include <QCoreApplication>
#include <iostream>
#include <ctime>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;
#define MAX_Deliveries_SIZE 100
class Deliveries
{
   string id,
          rdd,
          location,
          classification,
          mediaType,
          shippingMethod,
          rsd;
   int  nums;
public:
   //  constructors
          Deliveries();
   // Set variables
   void   set_ID(string ID);
   void   set_RDD (string RDD);
   void   set_Location   (string Location);
   void   set_Classification   (string Classification);
   void   set_MediaType   (string MediaType);
   void   set_ShippingMethod  (string ShippingMethod);
   void   set_RSD   (string RSD);
   void   set_NUMS   (int NUMS);
   // Get member variables
   string get_ID() {return id;}
   string get_RDD() {return rdd;}
   string  get_Location    () {return location;}
   string get_Classification() {return classification;}
   string   get_MediaType()   {return mediaType;}
   string   get_ShippingMethod()  {return shippingMethod;}
   string   get_RSD()   {return rsd;}
   int   get_NUMS()   {return nums;}
   void print_delivery_info();
};

Deliveries::Deliveries()
{
    id = '\0';
    rdd = '\0';
    location = '\0';
    classification = '\0';
    mediaType = '\0';
    shippingMethod= '\0';
    rsd = '\0';
    nums = 0;
}
void Deliveries::set_ID(string ID)
{
    id = ID;
}
void Deliveries::set_RDD(string RDD)
{
    rdd = RDD;
}
void Deliveries::set_Location (string Location)
{
    location = Location;
}
void  Deliveries::set_Classification   (string Classification){
    classification = Classification;
}
void Deliveries::set_MediaType (string MediaType)
{
    mediaType = MediaType;
}
void Deliveries::set_ShippingMethod (string ShippingMethod )
{
    shippingMethod = ShippingMethod;
}
void Deliveries::set_RSD (string RSD)
{
    rsd = RSD;
}
void Deliveries::set_NUMS (int NUMS)
{
    nums = NUMS;
}

int DayOfTheWeek (int day, int week, int year);
string CalculateRSD (string RDD, string Location);
void DatePlusDays( struct tm* date, int days );
void Sorting(Deliveries *data, int count);
int StringToValue(string s);
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

  //  DayOfTheWeek(21, 10, 2018);
    Deliveries data[MAX_Deliveries_SIZE];

    int count = 0;
    ifstream file("F:\\deliveries.csv");

    string str;
    getline(file, str); // skip the first line
    while (getline(file, str))
    {

        istringstream iss(str);
        string token;
        int j = 0;
        while (getline(iss, token, ','))
        {
            if(j==0) data[count].set_ID(token);
            if(j==1)data[count].set_RDD(token);
            if(j==2)data[count].set_Location(token);
            if(j==4)data[count].set_Classification(token);
            if(j==5){
                stringstream geek(token);
                int x = 0;
                geek >> x;
                data[count].set_NUMS(x);
            }
            if(j==6)data[count].set_MediaType(token);
            j++;
         }
         count ++;
    }
    cout << " Original data";
    cout << endl;
    cout << "....";
    cout << endl;
    for(int w = 0; w < count; w++){
         cout << data[w].get_ID() << "\t";
         cout << data[w].get_RDD() << "\t";
         cout << data[w].get_Location() << "\t";
         cout << data[w].get_ShippingMethod() << "\t";
         cout << data[w].get_Classification() << "\t";
         cout << data[w].get_NUMS() << "\t" ;
         cout << data[w].get_MediaType() << "\t" ;
         cout << data[w].get_RSD() << "\t" ;
         cout << endl;
    }
    cout << " Calculating RSD and set the method of transit";
    cout << endl;
    cout << "....";
    cout << endl;
    for(int w = 0; w < count; w++){
         cout << data[w].get_ID() << "\t";
         cout << data[w].get_RDD() << "\t";
         cout << data[w].get_Location() << "\t";
         if(data[w].get_Location() == "Local") data[w].set_ShippingMethod("Hand carry");
         else data[w].set_ShippingMethod("Shipping");
         cout << data[w].get_ShippingMethod() << "\t";
         cout << data[w].get_Classification() << "\t";
         cout << data[w].get_NUMS() << "\t" ;
         cout << data[w].get_MediaType() << "\t" ;
         data[w].set_RSD(CalculateRSD(data[w].get_RDD(), data[w].get_Location()));
         cout << data[w].get_RSD() << "\t" ;
         cout << endl;
    }
    cout << " sorting";
    cout << endl;
    cout << "....";
    cout << endl;
    Sorting(data, count);
    for(int w = 0; w < count; w++){
         cout << data[w].get_ID() << "\t";
         cout << data[w].get_RDD() << "\t";
         cout << data[w].get_Location() << "\t";
         cout << data[w].get_ShippingMethod() << "\t";
         cout << data[w].get_Classification() << "\t";
         cout << data[w].get_NUMS() << "\t" ;
         cout << data[w].get_MediaType() << "\t" ;
         cout << data[w].get_RSD() << "\t" ;
         cout << endl;
    }
    return a.exec();
}
void Sorting(Deliveries data[], int count){

    for(int i = 0; i < count; i++){

        int index = i;
        int nearest_date_day, nearest_date_month, nearest_date_year;
        int top_classification = StringToValue(data[i].get_Classification());
        int max_num_items = data[i].get_NUMS();
        int farest_Location = StringToValue(data[i].get_Location());
        int most_valued_document = StringToValue(data[i].get_MediaType());
        istringstream rsd(data[i].get_RSD());
        string token;
        int m = 0;
        while (getline(rsd, token, '/')){
            stringstream geek(token);
            int x = 0;
            geek >> x;
            if(m==0) nearest_date_day = x;
            if(m==1) nearest_date_month = x;
            if(m==2) nearest_date_year = x;
            m++;
        }
        for(int j = i + 1; j < count; j++){
            int next_date_day, next_date_month, next_date_year;
            int next_classification = StringToValue(data[j].get_Classification());
            int next_num_items = data[j].get_NUMS();
            int next_Location = StringToValue(data[j].get_Location());
            int next_valued_document = StringToValue(data[j].get_MediaType());
            istringstream next_rsd(data[j].get_RSD());
            string next_token;
            int n = 0;
            while (getline(next_rsd, next_token, '/')){
                stringstream geek(next_token);
                int x = 0;
                geek >> x;
                if(n==0) next_date_day = x;
                if(n==1) next_date_month = x;
                if(n==2) next_date_year = x;
                n++;
            }
            if(next_date_year<= nearest_date_year && next_date_month <= nearest_date_month && next_date_day < nearest_date_day){
                nearest_date_day = next_date_day;
                nearest_date_month = next_date_month;
                nearest_date_year = next_date_year;
                index = j;
            }
            if(next_date_year<= nearest_date_year && next_date_month <= nearest_date_month && next_date_day == nearest_date_day){
                if(next_classification > top_classification){
                    top_classification = next_classification;
                    index = j;
                }
                if(next_classification == top_classification){
                    if(next_Location > farest_Location){
                        farest_Location = next_Location;
                        index = j;
                    }
                    if(next_Location == farest_Location){
                        if(next_num_items > max_num_items){
                            max_num_items = next_num_items;
                            index = j;
                        }
                        if(next_num_items == max_num_items){
                            if(next_valued_document > most_valued_document){
                                most_valued_document = next_valued_document;
                                index = j;
                            }
                        }

                    }
                }
            }
        }
        if(index != i){
           // cout << "swap";
            Deliveries swap = data[i];
            data[i] = data[index];
            data[index] = swap;

        }
    }
}
int StringToValue(string s){
    if(s == "Secret"|| s == "secret") return 3;
    else if(s == "restricted" ||s ==  "Restricted") return 2;
    else if(s == "confidential" || s == "Confidential") return 1;
    else if(s == "Outside US"|| s == "outside US") return 3;
    else if(s == "A" || s == "B"|| s == "C"||s == "D" || s == "E"
            ||s == "a" || s == "b"|| s== "c"||s == "d" || s == "e") return 2;
    else if(s == "Local" || s == "local") return 1;
    else if(s == "Documentation" || s== "documentation") return 1;
    else if(s == "DVD") return 2;
    else if(s == "Hardware" || s== "Hardware") return 3;
    else return 0;
}

int DayOfTheWeek (int day, int month, int year){
    tm time_in = { 0, 0, 0, // second, minute, hour
        day, month, year}; // 1-based day, 0-based month, year since 1900

    time_t time_temp = mktime(&time_in);

    //Note: Return value of localtime is not threadsafe, because it might be
    // (and will be) reused in subsequent calls to std::localtime!
    const tm * time_out = localtime(&time_temp);
    if (time_out->tm_wday == 0) return 4;
    else if (time_out->tm_wday == 4) return 1;
    else if (time_out->tm_wday == 5) return 2;
    else if (time_out->tm_wday == 6) return 3;
    else return 0;
    //Sunday == 0, Monday == 1, and so on ...
 //   cout << "Today is this day of the week: " << time_out->tm_wday << "\n";
  //  cout << "(Sunday is 0, Monday is 1, and so on...)\n";

}

void DatePlusDays( struct tm* date, int days )
{
    const time_t ONE_DAY = 24 * 60 * 60 ;

    // Seconds since start of epoch
    time_t date_seconds = mktime( date ) + (days * ONE_DAY) ;

    // Update caller's date
    // Use localtime because mktime converts to UTC so may change date
    *date = *localtime( &date_seconds ) ; ;
}
string CalculateRSD (string RDD, string Location){
    struct tm date = { 0, 0, 12 }; // nominal time midday (arbitrary).
    char buffer[80];
    string str; // return value

    if(Location == "Outside US" || Location == "outside us"){
        istringstream rdd(RDD);
        string token;
        int j = 0;

        while (getline(rdd, token, '/')){
            stringstream geek(token);
            int x = 0;
            geek >> x;
            if(j==0) date.tm_mday = x;
            if(j==1) date.tm_mon = x - 1;
            if(j==2) date.tm_year = x - 1900;
            j++;

        }
        DatePlusDays(&date, -21);
        if(DayOfTheWeek(date.tm_mday, date.tm_mon, date.tm_year) != 0){
            DatePlusDays(&date, -DayOfTheWeek(date.tm_mday, date.tm_mon, date.tm_year));
        }
        strftime(buffer,sizeof(buffer),"%d/%m/%Y", &date);
        str = buffer;


    }
    else if(Location == "A" || Location == "B"|| Location == "C"||Location == "D" || Location == "E"
            ||Location == "a" || Location == "b"|| Location == "c"||Location == "d" || Location == "e"){
        istringstream rdd(RDD);
        string token;
        int j = 0;

        while (getline(rdd, token, '/')){
            stringstream geek(token);
            int x = 0;
            geek >> x;
            if(j==0) date.tm_mday = x;
            if(j==1) date.tm_mon = x - 1;
            if(j==2) date.tm_year = x - 1900;
            j++;

        }
        DatePlusDays(&date, -7);
        if(DayOfTheWeek(date.tm_mday, date.tm_mon, date.tm_year) != 0){
            DatePlusDays(&date, -DayOfTheWeek(date.tm_mday, date.tm_mon, date.tm_year));
        }
        strftime(buffer,sizeof(buffer),"%d/%m/%Y", &date);
        str = buffer;

    }
    else{
        istringstream rdd(RDD);
        string token;
        int j = 0;

        while (getline(rdd, token, '/')){
            stringstream geek(token);
            int x = 0;
            geek >> x;
            if(j==0) date.tm_mday = x;
            if(j==1) date.tm_mon = x - 1;
            if(j==2) date.tm_year = x - 1900;
            j++;

        }

        if(DayOfTheWeek(date.tm_mday, date.tm_mon, date.tm_year) != 0){
            DatePlusDays(&date, -DayOfTheWeek(date.tm_mday, date.tm_mon, date.tm_year));
        }
        strftime(buffer,sizeof(buffer),"%d/%m/%Y", &date);
        str = buffer;
        }

    return str;

}

