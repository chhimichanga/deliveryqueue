#ifndef DELIVERYQUEUE_H
#define DELIVERYQUEUE_H

#include <QMainWindow>
#include <QDate>
#include <stdio.h>

namespace Ui {
class DeliveryQueue;
class Delivery;
}

class Delivery
{
    QDate dateDeliver;
    QDate dateShip;
    QDate dateStart;
    QString destination;
    int numberOfItems;
    int mediaType;
    QString classification;
    QString transitMethod;
    int staffAvailable;
};

class DeliveryQueue : public QMainWindow
{
    Q_OBJECT

public:
    explicit DeliveryQueue(QWidget *parent = nullptr);
    ~DeliveryQueue();
    QObject Delivery;

private:
    Ui::DeliveryQueue *ui;
};

#endif // DELIVERYQUEUE_H

