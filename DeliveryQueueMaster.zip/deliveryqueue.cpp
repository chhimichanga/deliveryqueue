#include "deliveryqueue.h"
#include "ui_deliveryqueue.h"

DeliveryQueue::DeliveryQueue(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DeliveryQueue)
{
    ui->setupUi(this);
}

DeliveryQueue::~DeliveryQueue()
{
    delete ui;
}

