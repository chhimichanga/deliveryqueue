# deliveryqueue
Senior design project to develop a queuing algorithm for fleet deliveries.
