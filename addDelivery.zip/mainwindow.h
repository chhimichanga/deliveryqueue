#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class frmAddDelivery;
}

class frmAddDelivery : public QMainWindow
{
    Q_OBJECT

public:
    explicit frmAddDelivery(QWidget *parent = nullptr);
    ~frmAddDelivery();



private:
    Ui::frmAddDelivery *ui;
};

#endif // MAINWINDOW_H
