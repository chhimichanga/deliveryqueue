/*Michael Chhim
 * Bruce Roderiques
 * Michael Smith
 * Tuan_Son Le
 * Yun Yang
 */
//Delivery Queue Senior Project

#include "mainwindow.h"
#include "ui_frmAddDelivery.h"
#include "ui_frmEditDelivery.h"

frmAddDelivery::frmAddDelivery(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::frmAddDelivery)
{
    ui->setupUi(this);

//Classification ComboBox
    ui->cboClassification->addItem("Secret");
    ui->cboClassification->addItem("Confidential");
    ui->cboClassification->addItem("Unclassified");

//Location ComboBox
    ui->cboLocation ->addItem("Area 51,Nevada");
    ui->cboLocation ->addItem("King's Bay,Georgia");
    ui->cboLocation ->addItem("Pensacola,Florida");
    ui->cboLocation ->addItem("Great Lakes,Illinois");
    ui->cboLocation ->addItem("Bremerton,Washington");
    ui->cboLocation ->addItem("New London,Connecticut");
    ui->cboLocation ->addItem("Rota, Spain");
//mediaType Combobox

    ui->cboMediaType->addItem("Software");
    ui->cboMediaType->addItem("Hardware");
    ui->cboMediaType->addItem("Documentation");

//staffingLevel Combobox

    ui->cboStaffing->addItem("1");
    ui->cboStaffing->addItem("2");
    ui->cboStaffing->addItem("3");

//deliveryMethod Combobox
    ui->cboShipping->addItem("Hand Carried");
    ui->cboShipping->addItem("Shipping");
}

frmAddDelivery::~frmAddDelivery()
{
    delete ui;
}



